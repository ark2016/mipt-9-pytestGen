# python-slugify 8.0.4 evaluation

Coverage scope: `slugify/slugify.py`; generation targets: slugify, smart_truncate.
Full upstream test.py: 82/82 passed.
Upstream coverage is already high; little coverage gain is possible.

Baseline lines: 85/92; branches: 46/50.

## existing: ok

Retained: 13; dropped: 0; LLM requests: 5; tokens: 7706; wall: 157.213s.
Measured gain over upstream: `{"line_percentage_points": 1.0869565217391353, "branch_percentage_points": 1.9999999999999907, "new_lines": [56], "new_arcs": ["55->56"], "lost_lines": [], "lost_arcs": []}`.

## cold: ok

Retained: 18; dropped: 1; LLM requests: 8; tokens: 11003; wall: 130.398s.
Measured gain over upstream: `{"line_percentage_points": 1.0869565217391353, "branch_percentage_points": 1.9999999999999907, "new_lines": [56], "new_arcs": ["55->56"], "lost_lines": [], "lost_arcs": []}`.

Cold mode has existing_tests=(); its standalone coverage is not incremental gain.
Generated files are rerun alone and with the full upstream suite; no failure filtering.
Upstream test source is withheld from prompts. Generated tests may be repaired.
Coverage/pass counts do not establish assertion quality or generalize to other libraries.
Runner logs are retained output tails, not complete subprocess transcripts.
See report.json and per-mode JSON for counts, coverage, outcomes, budgets and usage.
